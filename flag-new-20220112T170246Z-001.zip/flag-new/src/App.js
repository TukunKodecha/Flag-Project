import { useState, useEffect } from "react";
import Dropdown from "./Dropdown";
import Flag from "./Flag";
import "./App.css";

export default function App() {
  const [options, setOption] = useState([
    {
      value: "---select---",
      color: "black",
    },
    {
      value: "low",
      color: "grey",
    },
    {
      value: "medium",
      color: "blue",
    },
    {
      value: "high",
      color: "red",
    },
    {
      value: "critical",
      color: "grey",
    },
    {
      value: "clear",
      color: "grey",
    },
  ]);
  const [flagClicked, setFlagClicked] = useState(false);
  const [selectedFlag, setSelectedFlag] = useState({
    value: "---select---",
    color: "black",
  });

  const onSelectChange = (e) => {
    let selected = options.find((item, i) => item.value === e.target.value);
    setSelectedFlag(selected);
  };

  return (
    <div className="App">
      <div
        onClick={() => setFlagClicked(!flagClicked)}
        style={{
          border: `2px dashed ${selectedFlag.color}`,
          width: 65,
          height: 65,
          borderRadius: "50%",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          position: "relative",
        }}
      >
        {selectedFlag.value !== "---select---" ? (
          <p
            className="flag_label"
            style={{
              backgroundColor: selectedFlag.color,
              color: "#fff",
            }}
          >
            {selectedFlag.value}
          </p>
        ) : null}

        <Flag selectedFlag={selectedFlag} />
      </div>
      {flagClicked ? (
        <Dropdown onSelectChange={onSelectChange} options={options} />
      ) : null}
    </div>
  );
}
