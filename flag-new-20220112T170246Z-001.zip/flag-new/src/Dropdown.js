import "./App.css";

export default function Dropdown({ options, onSelectChange }) {
  return (
    <div className="dropdown">
      <select onChange={(e) => onSelectChange(e)}>
        {options.map((data, i) => (
          <option
            key={i}
            value={data.value}
            disabled={data.value === "---select---"}
            selected={data.value === "---select---"}
          >
            {data.value}
          </option>
        ))}
      </select>
    </div>
  );
}
